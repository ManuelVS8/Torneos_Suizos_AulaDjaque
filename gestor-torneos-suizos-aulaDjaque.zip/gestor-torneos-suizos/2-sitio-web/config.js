/* CONFIGURACIÓN · es el ÚNICO archivo de la web que tienes que editar.
   1) Pega entre las comillas la dirección de tu Script de Google (termina en /exec).
   2) Si quieres, escribe el nombre de tu centro o club: aparecerá en la cabecera.
   Los pasos detallados están en INSTRUCCIONES.pdf. */
window.GTS_CONFIG = {
  SCRIPT_URL: '',
  CENTRO: ''
};
